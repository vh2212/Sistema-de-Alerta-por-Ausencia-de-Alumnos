<!doctype html>
<html>
    <head>
        <link rel="shortcut icon" href="#" />
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Bienvenido</title>

        <link rel="stylesheet" href="Matutino/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="Matutino/estilos.css">
        <link rel="stylesheet" href="Matutino/plugins/sweetalert2/sweetalert2.min.css">        
        
        <link rel="stylesheet" type="text/css" href="Matutino/fuentes/iconic/css/material-design-iconic-font.min.css">
        
    </head>
    
    <body>
  

    <div class="container-login">

    
    <div class="row">
    

  <div class="card text-center border-success">
  <div class="card-header">
  </div>
  <div class="card-body">
    <h1 class="card-title">Bienvenido.</h1>
    <br>
    <h4 class="card-text">Seleccione el turno que desea consultar.</h4>
    <br>
    <a href="Matutino/index.php" class="btn btn-primary">Turno Matutino.</a>
    <a href="Vespertino/index.php" class="btn btn-primary">Turno Vespertino.</a>
  </div>
</div>

    </div>     
        
    
     <script src="Matutino/jquery/jquery-3.3.1.min.js"></script>    
     <script src="Matutino/bootstrap/js/bootstrap.min.js"></script>    
     <script src="Matutino/popper/popper.min.js"></script>    
        
     <script src="Matutino/plugins/sweetalert2/sweetalert2.all.min.js"></script>    
     <script src="Matutino/codigo.js"></script>    
    </body>
</html>