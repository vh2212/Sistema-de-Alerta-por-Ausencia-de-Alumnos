<?php



require 'FaltasBL.php';

class FaltasService
{
    private $faltas;
    private $FaltasBL;

    public function __construct()
    {
        $this->FaltasBL = new FaltasBL();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $faltas)
    {
        $this->faltas = $this->FaltasBL->create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $faltas);
        if($this->faltas > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }

    public function read($id)
    {
        $this->faltas = $this->FaltasBL->read($id);
        echo json_encode($this->faltas);
    }

    public function update($idAlumno, $faltas)
    {
        $this->faltas = $this->FaltasBL->update($idAlumno, $faltas);
        echo json_encode($this->faltas);
    }

    public function delete($idAlumno)
    {
        $this->faltas = $this->FaltasBL->delete($idAlumno);
        if($this->faltas > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }
}

$service = new faltasService();
switch ($_SERVER['REQUEST_METHOD']) 
{
    case 'GET':
        {
            if (empty($_GET['param'])) {
                $service->read($_GET['param']);
            } else {
                $service->read($_GET['param']);
            }
            
            
            break;
        }
        case 'POST':
        {
        //print_r($_POST);
        $data = json_decode(file_get_contents('php://input'), true);
            $service->create($data['id'],$data['idAlumno'],$data['matricula'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['grupo'],$data['faltas']);
            break;
        }
        case 'PUT':
        {
            $data = json_decode(file_get_contents('php://input'), true);
            $service->update($data['idAlumno'],$data['faltas']);
            break;
        }
        case 'DELETE':
        {
            parse_str(file_get_contents('php://input'), $_DELETE);
            if (empty($_GET['param'])) {
                $service->delete($_GET['param']);
            } else {
                $service->delete($_GET['param']);
            }
            break;
        }
        
    
}

?>