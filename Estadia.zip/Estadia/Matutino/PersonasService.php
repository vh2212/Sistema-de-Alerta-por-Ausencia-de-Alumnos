<?php



require 'PersonasBL.php';

class PersonasService
{
    private $personas;
    private $PersonasBL;

    public function __construct()
    {
        $this->PersonasBL = new PersonasBL();
    }

    public function create($nombre,$apPaterno,$apMaterno,$huella)
    {
        $this->personas = $this->PersonasBL->create($nombre,$apPaterno,$apMaterno,$huella);
        if($this->personas > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }

    public function read($id)
    {
        $this->personas = $this->PersonasBL->read($id);
        echo json_encode($this->personas);
    }

    public function update($id,$nombre,$apPaterno,$apMaterno,$huella)
    {
        $this->personas = $this->PersonasBL->update($id,$nombre,$apPaterno,$apMaterno,$huella);
        echo json_encode($this->personas);
    }

    public function delete($id)
    {
        $this->personas = $this->PersonasBL->delete($id);
        if($this->personas > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }
}

$service = new personasService();
switch ($_SERVER['REQUEST_METHOD']) 
{
    case 'GET':
        {
            if (empty($_GET['param'])) {
                $service->read($_GET['param']);
            } else {
                $service->read($_GET['param']);
            }
            
            
            break;
        }
        case 'POST':
        {
        //print_r($_POST);
        $data = json_decode(file_get_contents('php://input'), true);
            $service->create($data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['huella']);
            break;
        }
        case 'PUT':
        {
            $data = json_decode(file_get_contents('php://input'), true);
            $service->update($data['id'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['huella']);
            break;
        }
        case 'DELETE':
        {
            parse_str(file_get_contents('php://input'), $_DELETE);
            if (empty($_GET['param'])) {
                $service->delete($_GET['param']);
            } else {
                $service->delete($_GET['param']);
            }
            break;
        }
        
    
}

?>