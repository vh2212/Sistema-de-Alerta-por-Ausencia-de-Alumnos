<?php
 require 'Conexion.php';
class inasistenciasBL
{
    private $conn;

    public function __construct()
    {
        $this->conn = new Conexion();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        $lastInsertId = 0;
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "INSERT INTO inasistencias VALUES(
                        :id,
                        :idAlumno,
                        :matricula,
                        :nombre,
                        :apPaterno,
                        :apMaterno,
                        :grupo,
                        :telefono
                    )"
                );
                
                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':matricula', $matricula);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':grupo', $grupo);
                $sqlStatment->bindParam(':telefono', $telefono);

                $sqlStatment->execute();
                $lastInsertId = $connSQL->lastInsertId();

                $connSQL->commit();
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
        }

        return $lastInsertId;


    }
    public function read($id)
    {
     $this->conn->OpenConection();
     $connSQL = $this->conn->getConection();
     $arrayinasistencias =  Array();
     if ($id > 0) {
        
        $sqlQuery = "SELECT * FROM inasistencias WHERE id = ".$id;
     } else {
        $sqlQuery = "SELECT * FROM inasistencias";
     }
     foreach ($connSQL->query($sqlQuery) as $row ) 
     {
         $arrayinasistencias[] = array(
             'id' => $row['id'],
             'idAlumno' => $row['idAlumno'],
             'matricula' => $row['matricula'],
             'nombre' => $row['nombre'],
             'apPaterno'   => $row['apPaterno'],
             'apMaterno'   => $row['apMaterno'],
             'grupo'   => $row['grupo'],
             'telefono' => $row['telefono']
         );
     }

     return $arrayinasistencias;

    }
    public function update($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "UPDATE inasistencias
                        set id = :id,
                        idAlumno = :idAlumno,
                        apPaterno = :apPaterno,
                        apMaterno = :apMaterno,
                        grupo = :grupo,
                        telefono = :telefono
                        where idAlumno = :idAlumno
                        ");

                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':matricula', $matricula);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':grupo', $grupo);
                $sqlStatment->bindParam(':telefono', $telefono);
                

                $sqlStatment->execute();

                $connSQL->commit();
            }
            else {
                $idAlumno = 0;
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
            $idAlumno = 0;
        }

        return $idAlumno;
    }
    public function delete($idAlumno)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            
            if ($connSQL) {
                $connSQL->beginTransaction();
                $sqlStatment = $connSQL->prepare(
                    "DELETE FROM inasistencias
                    WHERE idAlumno = :idAlumno"
                );
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->execute();

                $connSQL->commit();

            }
        } catch (PDOException $e) {

            $connSQL->rollBack();
            $idAlumno = 0;
         
        }
        return $idAlumno;
        
    }
}






?>