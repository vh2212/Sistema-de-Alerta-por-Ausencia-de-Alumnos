<?php



require 'InasistenciasBL.php';

class InasistenciasService
{
    private $inasistencias;
    private $InasistenciasBL;

    public function __construct()
    {
        $this->InasistenciasBL = new InasistenciasBL();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono)
    {
        $this->inasistencias = $this->InasistenciasBL->create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono);
        if($this->inasistencias > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }

    public function read($id)
    {
        $this->inasistencias = $this->InasistenciasBL->read($id);
        echo json_encode($this->inasistencias);
    }

    public function update($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono)
    {
        $this->inasistencias = $this->InasistenciasBL->update($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $telefono);
        echo json_encode($this->inasistencias);
    }

    public function delete($idAlumno)
    {
        $this->inasistencias = $this->InasistenciasBL->delete($idAlumno);
        if($this->inasistencias > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }
}

$service = new inasistenciasService();
switch ($_SERVER['REQUEST_METHOD']) 
{
    case 'GET':
        {
            if (empty($_GET['param'])) {
                $service->read($_GET['param']);
            } else {
                $service->read($_GET['param']);
            }
            
            
            break;
        }
        case 'POST':
        {
        //print_r($_POST);
        $data = json_decode(file_get_contents('php://input'), true);
            $service->create($data['id'],$data['idAlumno'],$data['matricula'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['grupo'],$data['telefono']);
            break;
        }
        case 'PUT':
        {
            $data = json_decode(file_get_contents('php://input'), true);
            $service->update($data['id'],$data['idAlumno'],$data['matricula'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['grupo'],$data['telefono']);
            break;
        }
        case 'DELETE':
        {
            parse_str(file_get_contents('php://input'), $_DELETE);
            if (empty($_GET['param'])) {
                $service->delete($_GET['param']);
            } else {
                $service->delete($_GET['param']);
            }
            break;
        }
        
    
}

?>