<?php
 require 'Conexion.php';
class personasBL
{
    private $conn;

    public function __construct()
    {
        $this->conn = new Conexion();
    }

    public function create($nombre, $apPaterno, $apMaterno, $huella)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        $lastInsertId = 0;
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "INSERT INTO personas VALUES(
                        default,
                        :nombre,
                        :apPaterno,
                        :apMaterno,
                        :huella,
                        current_timestamp
                    )"
                );
                
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':huella', $huella);

                $sqlStatment->execute();
                $lastInsertId = $connSQL->lastInsertId();

                $connSQL->commit();
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
        }

        return $lastInsertId;


    }
    public function read($id)
    {
     $this->conn->OpenConection();
     $connSQL = $this->conn->getConection();
     $arraypersonas =  Array();
     if ($id > 0) {
        
        $sqlQuery = "SELECT * FROM personas WHERE id = ".$id;
     } else {
        $sqlQuery = "SELECT * FROM personas";
     }
     foreach ($connSQL->query($sqlQuery) as $row ) 
     {
         $arraypersonas[] = array(
             'id' => $row['id'],
             'nombre' => $row['nombre'],
             'apPaterno'   => $row['apPaterno'],
             'apMaterno'   => $row['apMaterno'],
             'huella'   => $row['huella'],
             'last_update' => $row['last_update']
         );
     }

     return $arraypersonas;

    }
    public function update($id,$nombre,$apPaterno,$apMaterno,$huella)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "UPDATE personas
                        set nombre = :nombre,
                        apPaterno = :apPaterno,
                        apMaterno = :apMaterno,
                        huella = :huella
                        where id = :id
                        ");
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':huella', $huella);                
                $sqlStatment->bindParam(':id', $id);
                

                $sqlStatment->execute();

                $connSQL->commit();
            }
            else {
                $id = 0;
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
            $id = 0;
        }

        return $id;
    }
    public function delete($id)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            
            if ($connSQL) {
                $connSQL->beginTransaction();
                $sqlStatment = $connSQL->prepare(
                    "DELETE FROM personas
                    WHERE id = :id"
                );
                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->execute();

                $connSQL->commit();

            }
        } catch (PDOException $e) {

            $connSQL->rollBack();
            $id = 0;
         
        }
        return $id;
        
    }
}






?>