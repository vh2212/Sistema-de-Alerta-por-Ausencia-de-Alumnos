<html>
<body style="background-color:#000000;">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<br><br><br>
<font  color="white"><h1 class="text-center">API DOCUMENTAL</h1></font>
<br><br>  
<div class="row">
  <div class="col-sm-6">
  <div class="card text-white bg-danger mb-3">
      <div class="card-body">
        <h5 class="card-title">Presencia</h5>
        <p class="card-text">Es un dispositivo electrónico equipado con sensores capaces de detectar cualquier movimiento en el área en la que está instalado. La finalidad es activar un sistema de iluminación, de climatización o ventilación o de vigilancia.</p>
        <p> PUT= { "presencia_id":"2","direccion":"entrada/salidad","tiempoArea":"5000" } </p>
        <p> GET=  ip/labsol/api/presencia/7  </p>
        <p> POST= {"direccion":"entrada/salidad","tiempoArea":"5000" } </p>
        <p> DELETE= ip/labsol/api/presencia/7  </p>
        
        <p class="text-right">
        
        </p>
      </div>
    </div>
  </div>

</div>


</body>
 </html>