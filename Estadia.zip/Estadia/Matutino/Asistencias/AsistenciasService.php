<?php



require 'AsistenciasBL.php';

class AsistenciasService
{
    private $asistencias;
    private $AsistenciasBL;

    public function __construct()
    {
        $this->AsistenciasBL = new AsistenciasBL();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo)
    {
        $this->asistencias = $this->AsistenciasBL->create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo);
        if($this->asistencias > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }

    public function read($id)
    {
        $this->asistencias = $this->AsistenciasBL->read($id);
        echo json_encode($this->asistencias);
    }

    public function update($idAlumno)
    {
        $this->asistencias = $this->AsistenciasBL->update($idAlumno);
        echo json_encode($this->asistencias);
    }

    public function delete($id)
    {
        $this->asistencias = $this->AsistenciasBL->delete($id);
        if($this->asistencias > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }
}

$service = new asistenciasService();
switch ($_SERVER['REQUEST_METHOD']) 
{
    case 'GET':
        {
            if (empty($_GET['param'])) {
                $service->read($_GET['param']);
            } else {
                $service->read($_GET['param']);
            }
            
            
            break;
        }
        case 'POST':
        {
        //print_r($_POST);
        $data = json_decode(file_get_contents('php://input'), true);
            $service->create($data['id'],$data['idAlumno'],$data['matricula'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['grupo']);
            break;
        }
        case 'PUT':
        {
            $data = json_decode(file_get_contents('php://input'), true);
            $service->update($data['idAlumno']);
            break;
        }
        case 'DELETE':
        {
            parse_str(file_get_contents('php://input'), $_DELETE);
            if (empty($_GET['param'])) {
                $service->delete($_GET['param']);
            } else {
                $service->delete($_GET['param']);
            }
            break;
        }
        
    
}

?>