<?php
 require 'Conexion.php';
class asistenciasBL
{
    private $conn;

    public function __construct()
    {
        $this->conn = new Conexion();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        $lastInsertId = 0;
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "INSERT INTO asistencias VALUES(
                        :id,
                        :idAlumno,
                        :matricula,
                        :nombre,
                        :apPaterno,
                        :apMaterno,
                        :grupo,
                        current_timestamp
                    )"
                );
                
                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':matricula', $matricula);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':grupo', $grupo);

                $sqlStatment->execute();
                $lastInsertId = $connSQL->lastInsertId();

                $connSQL->commit();
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
        }

        return $lastInsertId;


    }
    public function read($id)
    {
     $this->conn->OpenConection();
     $connSQL = $this->conn->getConection();
     $arrayasistencias =  Array();
     if ($id > 0) {
        
        $sqlQuery = "SELECT * FROM asistencias WHERE id = ".$id;
     } else {
        $sqlQuery = "SELECT * FROM asistencias";
     }
     foreach ($connSQL->query($sqlQuery) as $row ) 
     {
         $arrayasistencias[] = array(
             'id' => $row['id'],
             'idAlumno' => $row['idAlumno'],
             'matricula' => $row['matricula'],
             'nombre' => $row['nombre'],
             'apPaterno'   => $row['apPaterno'],
             'apMaterno'   => $row['apMaterno'],
             'grupo'   => $row['grupo'],
             'horaLlegada' => $row['horaLlegada']
         );
     }

     return $arrayasistencias;

    }
    public function update($idAlumno)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "UPDATE asistencias
                        set horaLlegada = current_timestamp
                        where idAlumno = :idAlumno
                        ");

                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                

                $sqlStatment->execute();

                $connSQL->commit();
            }
            else {
                $idAlumno = 0;
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
            $idAlumno = 0;
        }

        return $idAlumno;
    }
    public function delete($id)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            
            if ($connSQL) {
                $connSQL->beginTransaction();
                $sqlStatment = $connSQL->prepare(
                    "DELETE FROM asistencias
                    WHERE id = :id"
                );
                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->execute();

                $connSQL->commit();

            }
        } catch (PDOException $e) {

            $connSQL->rollBack();
            $id = 0;
         
        }
        return $id;
        
    }
}






?>