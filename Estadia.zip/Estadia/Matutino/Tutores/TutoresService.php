<?php



require 'TutoresBL.php';

class TutoresService
{
    private $tutores;
    private $TutoresBL;

    public function __construct()
    {
        $this->TutoresBL = new TutoresBL();
    }

    public function create($idTutor, $idAlumno, $nombre, $apPaterno, $apMaterno, $telefono)
    {
        $this->tutores = $this->TutoresBL->create($id, $idAlumno, $nombre, $apPaterno, $apMaterno, $telefono);
        if($this->tutores > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }

    public function read($idTutor)
    {
        $this->tutores = $this->TutoresBL->read($idTutor);
        echo json_encode($this->tutores);
    }

    public function update($idTutor, $idAlumno, $nombre, $apPaterno, $apMaterno, $telefono)
    {
        $this->tutores = $this->TutoresBL->update($idTutor, $idAlumno, $nombre, $apPaterno, $apMaterno, $telefono);
        echo json_encode($this->tutores);
    }

    public function delete($idAlumno)
    {
        $this->tutores = $this->TutoresBL->delete($idAlumno);
        if($this->tutores > 0) {
            $response[] = array('response' => true);
            echo json_encode("response:true");
        }
        else {
            $response[] = array('response' => false);
            echo json_encode("response:false");
        }
    }
}

$service = new tutoresService();
switch ($_SERVER['REQUEST_METHOD']) 
{
    case 'GET':
        {
            if (empty($_GET['param'])) {
                $service->read($_GET['param']);
            } else {
                $service->read($_GET['param']);
            }
            
            
            break;
        }
        case 'POST':
        {
        //print_r($_POST);
        $data = json_decode(file_get_contents('php://input'), true);
            $service->create($data['idTutor'],$data['idAlumno'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['telefono']);
            break;
        }
        case 'PUT':
        {
            $data = json_decode(file_get_contents('php://input'), true);
            $service->update($data['id'],$data['idAlumno'],$data['nombre'],$data['apPaterno'],$data['apMaterno'],$data['telefono']);
            break;
        }
        case 'DELETE':
        {
            parse_str(file_get_contents('php://input'), $_DELETE);
            if (empty($_GET['param'])) {
                $service->delete($_GET['param']);
            } else {
                $service->delete($_GET['param']);
            }
            break;
        }
        
    
}

?>