<?php
 require 'Conexion.php';
class tutoresBL
{
    private $conn;

    public function __construct()
    {
        $this->conn = new Conexion();
    }

    public function create($idTutor, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $telefono)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        $lastInsertId = 0;
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "INSERT INTO tutores VALUES(
                        :idTutor,
                        :idAlumno,
                        :nombre,
                        :apPaterno,
                        :apMaterno,
                        :telefono
                    )"
                );
                
                $sqlStatment->bindParam(':idTutor', $idTutor);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':telefono', $telefono);

                $sqlStatment->execute();
                $lastInsertId = $connSQL->lastInsertId();

                $connSQL->commit();
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
        }

        return $lastInsertId;


    }
    public function read($idAlumno)
    {
     $this->conn->OpenConection();
     $connSQL = $this->conn->getConection();
     $arraytutores =  Array();
     if ($idAlumno > 0) {
        //SELECT telefono FROM tutores WHERE idAlumno = 1
        $sqlQuery = "SELECT telefono FROM tutores WHERE idAlumno = ".$idAlumno;
     } else {
        $sqlQuery = "SELECT * FROM tutores";
     }
     foreach ($connSQL->query($sqlQuery) as $row ) 
     {
         $arraytutores[] = array(
             'telefono' => $row['telefono']
         );
     }

     return $arraytutores;

    }
    public function update($idTutor, $idAlumno, $nombre, $apPaterno, $apMaterno, $telefono)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "UPDATE tutores
                        set idTutor = :idTutor,
                        idAlumno = :idAlumno,
                        apPaterno = :apPaterno,
                        apMaterno = :apMaterno,
                        telefono = :telefono
                        where idAlumno = :idAlumno
                        ");

                $sqlStatment->bindParam(':idTutor', $idTutor);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':telefono', $telefono);
                

                $sqlStatment->execute();

                $connSQL->commit();
            }
            else {
                $idAlumno = 0;
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
            $idAlumno = 0;
        }

        return $idAlumno;
    }
    public function delete($idAlumno)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            
            if ($connSQL) {
                $connSQL->beginTransaction();
                $sqlStatment = $connSQL->prepare(
                    "DELETE FROM tutores
                    WHERE idAlumno = :idAlumno"
                );
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->execute();

                $connSQL->commit();

            }
        } catch (PDOException $e) {

            $connSQL->rollBack();
            $idAlumno = 0;
         
        }
        return $idAlumno;
        
    }
}






?>