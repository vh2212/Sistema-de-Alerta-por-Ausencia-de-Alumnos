<?php
 require 'Conexion.php';
class faltasBL
{
    private $conn;

    public function __construct()
    {
        $this->conn = new Conexion();
    }

    public function create($id, $idAlumno, $matricula, $nombre, $apPaterno, $apMaterno, $grupo, $faltas)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        $lastInsertId = 0;
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "INSERT INTO faltas2 VALUES(
                        :id,
                        :idAlumno,
                        :matricula,
                        :nombre,
                        :apPaterno,
                        :apMaterno,
                        :grupo,
                        :faltas
                    )"
                );
                
                $sqlStatment->bindParam(':id', $id);
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':matricula', $matricula);
                $sqlStatment->bindParam(':nombre', $nombre);
                $sqlStatment->bindParam(':apPaterno', $apPaterno);
                $sqlStatment->bindParam(':apMaterno', $apMaterno);
                $sqlStatment->bindParam(':grupo', $grupo);
                $sqlStatment->bindParam(':faltas', $faltas);

                $sqlStatment->execute();
                $lastInsertId = $connSQL->lastInsertId();

                $connSQL->commit();
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
        }

        return $lastInsertId;


    }
    public function read($id)
    {
     $this->conn->OpenConection();
     $connSQL = $this->conn->getConection();
     $arrayfaltas =  Array();
     if ($id > 0) {
        
        $sqlQuery = "SELECT * FROM faltas2 WHERE id = ".$id;
     } else {
        $sqlQuery = "SELECT * FROM faltas2";
     }
     foreach ($connSQL->query($sqlQuery) as $row ) 
     {
         $arrayfaltas[] = array(
             'id' => $row['id'],
             'idAlumno' => $row['idAlumno'],
             'matricula' => $row['matricula'],
             'nombre' => $row['nombre'],
             'apPaterno'   => $row['apPaterno'],
             'apMaterno'   => $row['apMaterno'],
             'grupo'   => $row['grupo'],
             'faltas' => $row['faltas']
         );
     }

     return $arrayfaltas;

    }
    public function update($idAlumno, $faltas)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            if ($connSQL) {
                $connSQL->beginTransaction();

                $sqlStatment = $connSQL->prepare(
                    "UPDATE faltas2
                        set faltas = :faltas
                        where idAlumno = :idAlumno
                        ");

                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->bindParam(':faltas', $faltas);
                

                $sqlStatment->execute();

                $connSQL->commit();
            }
            else {
                $idAlumno = 0;
            }
            
        } catch (PDOException $e) {
            $connSQL->rollBack();
            $idAlumno = 0;
        }

        return $idAlumno;
    }
    public function delete($idAlumno)
    {
        $this->conn->OpenConection();
        $connSQL = $this->conn->getConection();
        try {
            
            if ($connSQL) {
                $connSQL->beginTransaction();
                $sqlStatment = $connSQL->prepare(
                    "DELETE FROM faltas2
                    WHERE idAlumno = :idAlumno"
                );
                $sqlStatment->bindParam(':idAlumno', $idAlumno);
                $sqlStatment->execute();

                $connSQL->commit();

            }
        } catch (PDOException $e) {

            $connSQL->rollBack();
            $idAlumno = 0;
         
        }
        return $idAlumno;
        
    }
}






?>