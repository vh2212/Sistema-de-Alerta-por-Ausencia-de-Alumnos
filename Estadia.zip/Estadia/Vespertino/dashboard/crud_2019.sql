-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-02-2019 a las 01:16:27
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `crud_2019`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--
-- CREATE TABLE `alumnos` (`idAlumno` int(10) NOT NULL,`nombre` varchar(20) COLLATE utf8_spanish_ci NOT NULL,`apPaterno` varchar(20) COLLATE utf8_spanish_ci NOT NULL,`apMaterno` varchar(20) COLLATE utf8_spanish_ci NOT NULL,`huella` int(11) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
--INSERT INTO `alumnos3` (`id`, `nombre`, `apPaterno`, `apMaterno`, `huella`) VALUES
--(1, 'María', 'Perez', 'Gomez', 52),
--(2, 'Jorge', 'Silva', 'Castro', 48),
--(3, 'Silvia', 'Olvera', 'Sanchez', 25),
--(4, 'Ramiro', 'Perez', 'Ruiz', 35);

-- Estructura de tabla para la tabla `alumnos`
CREATE TABLE alumnos2(
  idAlumno INT NOT NULL,
  matricula VARCHAR(20) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apPaterno VARCHAR(20) NOT NULL,
  apMaterno VARCHAR(20) NOT NULL,
  grupo VARCHAR(10) NOT NULL,
  PRIMARY KEY  (idAlumno)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
INSERT INTO alumnos2 values (1, '20183L201004', 'Victor', 'Hernandez', 'Garcia', '101');


-- Estructura de tabla para la tabla `Tutores`
CREATE TABLE tutores2(
  idTutor INT NOT NULL,
  idAlumno INT NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apPaterno VARCHAR(20) NOT NULL,
  apMaterno VARCHAR(20) NOT NULL,
  telefono VARCHAR(10) NOT NULL,
  PRIMARY KEY  (idTutor),
  FOREIGN KEY (idAlumno) REFERENCES alumnos2(idAlumno)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
INSERT INTO tutores2 values (1, 1, 'Irma', 'Garcia', 'Fuentes', '2711163147');

-- Estructura de tabla para la tabla `Asistencias`
CREATE TABLE asistencias2(
  id INT NOT NULL,
  idAlumno INT NOT NULL,
  matricula VARCHAR(20) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apPaterno VARCHAR(20) NOT NULL,
  apMaterno VARCHAR(20) NOT NULL,
  grupo VARCHAR(10) NOT NULL,
  horaLlegada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  FOREIGN KEY (idAlumno) REFERENCES alumnos2(idAlumno)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
INSERT INTO asistencias2 values (1, 1, '20183L201004', 'Victor', 'Hernandez', 'Garcia', '101', current_timestamp);

-- Estructura de tabla para la tabla `inasistencias`
CREATE TABLE inasistencias2(
  id INT NOT NULL,
  idAlumno INT NOT NULL,
  matricula VARCHAR(20) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apPaterno VARCHAR(20) NOT NULL,
  apMaterno VARCHAR(20) NOT NULL,
  grupo VARCHAR(10) NOT NULL,
  telefono VARCHAR(10) NOT NULL,
  PRIMARY KEY  (id),
  FOREIGN KEY (idAlumno) REFERENCES alumnos2(idAlumno)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
INSERT INTO inasistencias2 values (1, 1, '20183L201004', 'Victor', 'Hernandez', 'Garcia', '101', '2711163147');

-- Estructura de tabla para la tabla `faltas`
CREATE TABLE faltas2(
  id INT NOT NULL,
  idAlumno INT NOT NULL,
  matricula VARCHAR(20) NOT NULL,
  nombre VARCHAR(20) NOT NULL,
  apPaterno VARCHAR(20) NOT NULL,
  apMaterno VARCHAR(20) NOT NULL,
  grupo VARCHAR(10) NOT NULL,
  faltas INT NOT NULL,
  PRIMARY KEY  (id),
  FOREIGN KEY (idAlumno) REFERENCES alumnos2(idAlumno)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
INSERT INTO faltas2 values (1, 1, '20183L201004', 'Victor', 'Hernandez', 'Garcia', '101', 2);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
--ALTER TABLE `alumnos3`
--  ADD PRIMARY KEY (`id`);

--ALTER TABLE `alumnos3`
--  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--COMMIT;

